from ._tesserocr import *
